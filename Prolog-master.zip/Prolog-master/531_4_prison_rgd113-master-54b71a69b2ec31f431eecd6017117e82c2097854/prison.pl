/*

    Module 531: Laboratory (Prolog)
    Exercise No.4  (prison)

*/


% May be helpful for testing

% generate_integer(+Min, +Max, -I)
%   I is an integer in the range Min <= I <= Max

generate_integer(Min,Max,Min):-
  Min =< Max.
generate_integer(Min,Max,I) :-
  Min < Max,
  NewMin is Min + 1,
  generate_integer(NewMin,Max,I).
  
  
% Uncomment this line to use the provided database for Problem 2.
% You MUST recomment or remove it from your submitted solution.
% :- include(prisonDb).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%     Problem 1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% prison_game(+Cells, +Warders, -Escaped)
%   Escaped is a list of cell numbers for prisoners who will escape
%   once all warders have completed their runs.

prison_game(Cells, Warders, Escaped) :-
  integer(Cells), Cells > 0,
  integer(Warders), Warders > 0,
  make_list(Cells, unlocked, Initial),
  run_warders(2, Warders, Initial, Final),
  extract_indices(Final, unlocked, Escaped).
  

% Write your program here.

% Task 1.1 make_list(+N, +Item, -List).
%   Given a (non-negative) integer N and item Item constructs list List of N
%   elements each of which is Item

% Base case
make_list(0,_,[]):-!.

% Recursive case
make_list(N, Item, [Item|List]) :-
	Nnew is N-1,
	make_list(Nnew,Item,List).


% Task 1.2 extract_indices(+List, +Item, -Indices).
%   Given list List and item Item computes the list Indices of integers N such
%   that Item is the Nth item of the list List

% Trivial case
extract_indices([], _, []).

% Non trivial case
extract_indices(List, Item, Indices) :-
	extract_indices(List, 1, Item, Indices).

% Base case
extract_indices([],_,_,[]).

% Recursive cases
extract_indices([Item|T], N, Item, [N|Indices]) :-
	Nnew is N+1,
	!,	
	extract_indices(T,Nnew,Item,Indices).

extract_indices([_|T], N, Item, Indices) :-
	Nnew is N+1,	
	extract_indices(T,Nnew,Item,Indices).


% Task 1.3 run_warders(+N, +W, +Initial, -Final). 
%   Given next warder N and total warders W (both positive integers), and 
%   current door states Initial (a list of the constants locked and unlocked) 
%   returns Final, the list of door states after all warders have completed 
%   their runs.

% Base case
run_warders(N, W, Final, Final) :-
	K is W+1,
	N == K,
	!.

% Recursive case
run_warders(N, W, Initial, Final) :-
	run_warder(N, 1, Initial, Intermediate),
	Nnew is N+1,
	run_warders(Nnew, W, Intermediate, Final).     

% Base case
run_warder(_,_,[],[]).

% Recursive cases
run_warder(N,N,[locked|T],[unlocked|Final]) :-
	run_warder(N,1,T,Final).

run_warder(N,N,[unlocked|T],[locked|Final]) :-
	run_warder(N,1,T,Final).

run_warder(N,Acc,[H|T],[H|Final]) :-
	N \= Acc,
	Newacc is Acc + 1,
	run_warder(N,Newacc,T,Final).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%     Problem 2
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Write your program here.

% Task 2.1 cell_status(+Cell, +N, ?Status)
%   Succeeds if the status of cell Cell is Status after N warders have made 
%   their runs. If Status is a variable, then the correct value should be 
%   returned.


cell_status(Cell,N,S) :-
	cell_status(Cell,N,locked,S).

% Base case
cell_status(_,0,S,S):-!.

% Check if there is a psychopath in the cell
cell_status(Cell,N,locked,S) :-
	N \== 0,
	prisoner(L,F,Cell,_,_,_),
	psychopath(L,F),
	!,
	cell_status(Cell,0,locked,S).

% Recursive case
cell_status(Cell, N, locked,S) :- 
	N \== 0,
	M is mod(Cell,N),
	M == 0,
	Newn is N-1,
	cell_status(Cell,Newn,unlocked,S).     


cell_status(Cell, N, unlocked,S) :- 
	N \== 0,
	M is mod(Cell,N),
	M == 0,
	Newn is N-1,
	cell_status(Cell,Newn,locked,S).  

cell_status(Cell, N, locked,S) :- 
	N \== 0,
	M is mod(Cell,N),
	M \== 0,
	Newn is N-1,
	cell_status(Cell,Newn,locked,S).     


cell_status(Cell, N, unlocked,S) :- 
	N \== 0,
	M is mod(Cell,N),
	M \== 0,
	Newn is N-1,
	cell_status(Cell,Newn,unlocked,S).     


% Task 2.2 

% escaped(?Surname, ?FirstName)
%   holds when the prisoner with that name escapes (i.e., occupies a cell which 
%   is unlocked after the last warder has made his run, but bearing in mind that
%   prisoners with a year or less left to serve will not escape).

escaped(L, F) :-
	prisoner(L,F,C,_,_,S),
	S > 1,
	warders(W),
	cell_status(C,W,unlocked).


% escapers(-List)
%   List is the list of escaped prisoners. List is a list of terms of the form 
%   (Surname, FirstName), sorted in ascending alphabetical order according to 
%   Surname.

escapers(Sorted) :-
	findall((L,F),escaped(L,F),List), 
	sort(List,Sorted).



