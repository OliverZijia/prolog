% --- sample prison database ---

cells(80).

warders(30).

prisoner('Sadri', 'Emil', 1, robbery, 8, 8).
prisoner('Yang', 'Alessio', 2, burglary, 6, 5).
prisoner('McBrien', 'Jeremy', 2, rape, 21, 16).
prisoner('Huth', 'Sebastian', 2, burglary, 6, 3).
prisoner('Luk', 'Francesca', 3, burglary, 2, 2).
prisoner('Davidson', 'Marek', 3, rape, 19, 4).
prisoner('Clark', 'Margaret', 3, attempted_murder, 32, 19).
prisoner('Donaldson', 'Michael', 3, rape, 6, 3).
prisoner('Pietzuch', 'Murray', 3, murder, 25, 3).
prisoner('Lomuscio', 'Paul', 3, burglary, 5, 1).
prisoner('Russo', 'Maja', 4, murder, 32, 2).
prisoner('Yoshida', 'Abbas', 5, murder, 22, 4).
prisoner('Wiklicky', 'Keith', 6, burglary, 7, 4).
prisoner('Donaldson', 'Sebastian', 6, robbery, 7, 5).
prisoner('Clark', 'Francesca', 8, rape, 6, 1).
prisoner('Van Bakel', 'Yike', 8, burglary, 4, 1).
prisoner('Knottenbelt', 'Herbert', 9, assault, 11, 11).
prisoner('Donaldson', 'Keith', 9, murder, 49, 14).
prisoner('Lomuscio', 'Morris', 10, assault, 10, 4).
prisoner('Sadri', 'Murray', 10, burglary, 5, 2).
prisoner('McBrien', 'Chris', 11, rape, 18, 6).
prisoner('Rustem', 'Francesca', 11, rape, 7, 5).
prisoner('Hodkinson', 'Herbert', 11, murder, 44, 13).
prisoner('Rustem', 'Ian', 11, assault, 15, 10).
prisoner('Dulay', 'Sophia', 11, plagiarism, 3, 3).
prisoner('Uchitel', 'Steffen', 11, burglary, 2, 1).
prisoner('Guo', 'Ian', 12, murder, 50, 6).
prisoner('Pantic', 'Jeremy', 12, burglary, 7, 3).
prisoner('Rustem', 'John', 12, rape, 14, 11).
prisoner('Edalat', 'Julie', 12, assault, 12, 6).
prisoner('Cunningham', 'Nobuko', 12, attempted_murder, 24, 13).
prisoner('Wiklicky', 'Krysia', 13, burglary, 7, 2).
prisoner('Hodkinson', 'Tony', 13, robbery, 15, 8).
prisoner('Sergot', 'Alessandra', 14, murder, 29, 23).
prisoner('Yang', 'Andrew', 14, attempted_murder, 17, 5).
prisoner('Hankin', 'Margaret', 14, attempted_murder, 36, 25).
prisoner('Luk', 'Philippa', 14, assault, 10, 4).
prisoner('Lomuscio', 'Alex', 15, assault, 11, 11).
prisoner('Guo', 'Daniel', 15, murder, 36, 15).
prisoner('Darlington', 'Margaret', 15, attempted_murder, 18, 15).
prisoner('Knottenbelt', 'Andrew', 16, rape, 18, 6).
prisoner('Wiklicky', 'Duncan', 16, robbery, 12, 10).
prisoner('McCann', 'John', 16, rape, 5, 4).
prisoner('Toni', 'Murray', 16, murder, 26, 16).
prisoner('Phillips', 'Jeff', 19, robbery, 6, 6).
prisoner('Yoshida', 'Sebastian', 19, burglary, 6, 4).
prisoner('Yoshida', 'Steffen', 19, attempted_murder, 29, 28).
prisoner('Russo', 'Marek', 20, plagiarism, 2, 1).
prisoner('Lupu', 'Marek', 21, murder, 44, 36).
prisoner('Wiklicky', 'Susan', 21, robbery, 5, 5).
prisoner('Darlington', 'Duncan', 22, murder, 36, 32).
prisoner('Yoshida', 'John', 22, robbery, 8, 2).
prisoner('Clark', 'Daniel', 23, robbery, 12, 7).
prisoner('Cunningham', 'Naranker', 24, attempted_murder, 16, 3).
prisoner('Uchitel', 'Philippa', 24, attempted_murder, 27, 7).
prisoner('Drossopoulou', 'Margaret', 25, attempted_murder, 40, 3).
prisoner('Dulay', 'Michael', 25, burglary, 4, 2).
prisoner('Darlington', 'Stephen', 25, assault, 12, 7).
prisoner('Broda', 'Will', 25, murder, 39, 9).
prisoner('Muggleton', 'Andrew', 26, attempted_murder, 36, 30).
prisoner('Hodkinson', 'Guang Zhong', 26, attempted_murder, 37, 6).
prisoner('Kramer', 'Jeremy', 26, murder, 42, 37).
prisoner('Pietzuch', 'Julie', 26, rape, 6, 4).
prisoner('Russo', 'Duncan', 27, assault, 9, 1).
prisoner('Harrison', 'Nobuko', 27, murder, 31, 19).
prisoner('Clark', 'Philippa', 27, rape, 13, 6).
prisoner('Calcagno', 'Susan', 27, murder, 46, 38).
prisoner('Pietzuch', 'Susan', 27, assault, 8, 4).
prisoner('Lomuscio', 'Berc', 28, plagiarism, 5, 1).
prisoner('Gardner', 'Morris', 28, assault, 14, 9).
prisoner('Sergot', 'Murray', 28, rape, 20, 11).
prisoner('Davidson', 'Paul', 28, murder, 48, 2).
prisoner('Kramer', 'Paul', 28, murder, 32, 32).
prisoner('Yang', 'Will', 28, attempted_murder, 35, 13).
prisoner('Van Bakel', 'John', 29, murder, 38, 19).
prisoner('Edalat', 'Chris', 30, rape, 21, 12).
prisoner('Donaldson', 'Francesca', 31, rape, 5, 3).
prisoner('Pantic', 'Peter', 31, rape, 17, 9).
prisoner('Sadri', 'Herbert', 32, murder, 43, 8).
prisoner('Sloman', 'Jeremy', 32, robbery, 5, 1).
prisoner('Sloman', 'Keith', 32, murder, 32, 14).
prisoner('Van Bakel', 'Margaret', 32, assault, 10, 2).
prisoner('Dulay', 'Paul', 32, murder, 38, 27).
prisoner('Muggleton', 'Tony', 32, assault, 14, 14).
prisoner('Huth', 'Abbas', 33, plagiarism, 5, 1).
prisoner('McCann', 'Jeremy', 33, robbery, 15, 9).
prisoner('Broda', 'Berc', 34, robbery, 13, 13).
prisoner('McBrien', 'Emil', 34, burglary, 6, 4).
prisoner('Magee', 'Alastair', 35, robbery, 14, 8).
prisoner('Calcagno', 'Daniel', 35, plagiarism, 4, 1).
prisoner('Guo', 'Sophia', 35, murder, 23, 2).
prisoner('Darlington', 'Alex', 36, robbery, 15, 2).
prisoner('Hankin', 'Guang Zhong', 36, robbery, 5, 5).
prisoner('Hodkinson', 'Alex', 37, plagiarism, 5, 1).
prisoner('Shanahan', 'Marek', 37, murder, 42, 29).
prisoner('Hankin', 'Morris', 37, plagiarism, 4, 3).
prisoner('Magee', 'Fariba', 38, plagiarism, 2, 1).
prisoner('Guo', 'Maja', 38, murder, 35, 21).
prisoner('Phillips', 'Berc', 39, murder, 24, 10).
prisoner('Bradley', 'Fariba', 40, murder, 22, 20).
prisoner('Gillies', 'Peter', 40, robbery, 13, 10).
prisoner('Bradley', 'Sophia', 40, plagiarism, 4, 3).
prisoner('Cunningham', 'Wayne', 41, assault, 14, 13).
prisoner('Hankin', 'Susan', 42, murder, 44, 6).
prisoner('Kelly', 'Abbas', 43, robbery, 6, 5).
prisoner('Toni', 'Guang Zhong', 44, rape, 5, 3).
prisoner('Cunningham', 'Fariba', 45, robbery, 9, 7).
prisoner('Field', 'Yike', 45, assault, 13, 2).
prisoner('Pietzuch', 'Cristiano', 46, attempted_murder, 24, 5).
prisoner('Russo', 'Cristiano', 46, attempted_murder, 16, 9).
prisoner('Hodkinson', 'Sebastian', 46, robbery, 13, 8).
prisoner('Sadri', 'Yike', 46, attempted_murder, 16, 12).
prisoner('McCann', 'Iain', 47, plagiarism, 4, 3).
prisoner('Drossopoulou', 'Maja', 47, rape, 16, 15).
prisoner('Lupu', 'Berc', 48, murder, 23, 22).
prisoner('Field', 'Emil', 48, rape, 18, 15).
prisoner('Sloman', 'Duncan', 49, robbery, 9, 7).
prisoner('Broda', 'Susan', 49, rape, 9, 6).
prisoner('Kelly', 'Duncan', 50, robbery, 14, 9).
prisoner('Eisenbach', 'Francesca', 50, rape, 11, 10).
prisoner('Lupu', 'Jeremy', 50, murder, 38, 7).
prisoner('Eisenbach', 'Andrew', 51, rape, 6, 1).
prisoner('Huth', 'Alessio', 52, rape, 19, 17).
prisoner('Uchitel', 'Alessio', 52, rape, 19, 2).
prisoner('Uchitel', 'Cristiano', 52, robbery, 8, 2).
prisoner('Dulay', 'Susan', 52, plagiarism, 2, 1).
prisoner('Sergot', 'Wayne', 52, burglary, 7, 7).
prisoner('Calcagno', 'Alessandra', 53, murder, 31, 24).
prisoner('Knottenbelt', 'Margaret', 53, plagiarism, 1, 1).
prisoner('Sloman', 'Maja', 54, rape, 7, 1).
prisoner('Rueckert', 'Murray', 54, robbery, 5, 1).
prisoner('Kelly', 'Naranker', 55, plagiarism, 3, 2).
prisoner('Wolf', 'Will', 55, assault, 8, 2).
prisoner('Van Bakel', 'Krysia', 56, rape, 14, 7).
prisoner('Gardner', 'Marek', 56, robbery, 9, 3).
prisoner('Bradley', 'Paul', 57, rape, 13, 11).
prisoner('Phillips', 'Steffen', 57, robbery, 14, 2).
prisoner('Rueckert', 'Yike', 57, burglary, 6, 6).
prisoner('Pietzuch', 'Alex', 58, robbery, 5, 1).
prisoner('Sadri', 'Daniel', 58, assault, 7, 7).
prisoner('Shanahan', 'Alex', 59, burglary, 5, 3).
prisoner('Kramer', 'Berc', 59, plagiarism, 3, 1).
prisoner('Toni', 'Duncan', 59, attempted_murder, 36, 13).
prisoner('Eisenbach', 'Iain', 59, murder, 49, 11).
prisoner('Guo', 'Sebastian', 59, murder, 31, 2).
prisoner('Toni', 'Alastair', 60, assault, 10, 2).
prisoner('Phillips', 'Guang Zhong', 60, assault, 9, 6).
prisoner('Gillies', 'Marek', 60, plagiarism, 3, 1).
prisoner('Harrison', 'Marek', 60, assault, 7, 3).
prisoner('Luk', 'Morris', 60, burglary, 6, 5).
prisoner('Muggleton', 'Will', 60, rape, 8, 8).
prisoner('Drossopoulou', 'Alessandra', 61, plagiarism, 4, 1).
prisoner('Eisenbach', 'John', 61, robbery, 14, 8).
prisoner('McBrien', 'Nobuko', 61, attempted_murder, 36, 29).
prisoner('Kramer', 'Wayne', 61, assault, 14, 10).
prisoner('Shanahan', 'Fariba', 62, burglary, 2, 2).
prisoner('McCann', 'Herbert', 62, burglary, 4, 1).
prisoner('Rustem', 'Krysia', 62, murder, 50, 38).
prisoner('Wolf', 'Sophia', 62, murder, 34, 3).
prisoner('Rueckert', 'Tony', 62, assault, 9, 2).
prisoner('Magee', 'Ian', 63, assault, 6, 2).
prisoner('Magee', 'Sophia', 63, plagiarism, 3, 3).
prisoner('Eisenbach', 'Daniel', 64, attempted_murder, 35, 30).
prisoner('Dulay', 'Julie', 64, murder, 30, 20).
prisoner('Harrison', 'Will', 64, plagiarism, 4, 4).
prisoner('Gillies', 'Alastair', 66, plagiarism, 2, 2).
prisoner('Calcagno', 'Abbas', 67, assault, 5, 1).
prisoner('Lupu', 'Cristiano', 67, burglary, 4, 4).
prisoner('Edalat', 'Alastair', 68, burglary, 4, 4).
prisoner('Gardner', 'Jeff', 69, rape, 20, 12).
prisoner('Edalat', 'John', 69, rape, 25, 5).
prisoner('Wolf', 'Marek', 69, robbery, 8, 6).
prisoner('Yang', 'Susan', 69, rape, 20, 15).
prisoner('Broda', 'Alessio', 70, murder, 37, 10).
prisoner('Davidson', 'Alessio', 70, robbery, 5, 4).
prisoner('Field', 'Michael', 70, robbery, 7, 7).
prisoner('Sloman', 'Nobuko', 70, assault, 7, 2).
prisoner('Gardner', 'Andrew', 71, attempted_murder, 28, 11).
prisoner('Davidson', 'Iain', 71, robbery, 5, 4).
prisoner('Wolf', 'Julie', 71, assault, 9, 3).
prisoner('Bradley', 'Krysia', 71, assault, 15, 15).
prisoner('Field', 'Morris', 71, assault, 13, 5).
prisoner('Shanahan', 'Steffen', 71, assault, 10, 3).
prisoner('Knottenbelt', 'Peter', 72, assault, 7, 5).
prisoner('Kelly', 'Philippa', 72, murder, 35, 5).
prisoner('Luk', 'Steffen', 72, rape, 10, 6).
prisoner('Muggleton', 'Susan', 72, attempted_murder, 31, 6).
prisoner('Gillies', 'Philippa', 74, plagiarism, 1, 1).
prisoner('Rueckert', 'Emil', 75, assault, 6, 6).
prisoner('Toni', 'Susan', 75, plagiarism, 5, 3).
prisoner('Huth', 'Herbert', 76, rape, 7, 6).
prisoner('Sergot', 'Ian', 76, plagiarism, 5, 2).
prisoner('Pantic', 'Susan', 77, plagiarism, 4, 2).
prisoner('Yoshida', 'Julie', 78, murder, 27, 10).
prisoner('Field', 'Ian', 79, robbery, 11, 11).
prisoner('Drossopoulou', 'John', 79, plagiarism, 5, 4).
prisoner('Harrison', 'Paul', 79, burglary, 6, 5).
prisoner('Pantic', 'Paul', 79, plagiarism, 4, 1).
prisoner('Edalat', 'Susan', 79, robbery, 15, 13).
prisoner('Pantic', 'Tony', 79, rape, 13, 9).


psychopath('Hodkinson', 'Herbert').
psychopath('Muggleton', 'Andrew').
psychopath('Hodkinson', 'Guang Zhong').
psychopath('Kramer', 'Jeremy').
psychopath('Yang', 'Will').
psychopath('Sadri', 'Herbert').
psychopath('Shanahan', 'Marek').
psychopath('Toni', 'Duncan').
psychopath('Rustem', 'Krysia').
psychopath('Eisenbach', 'Daniel').


