% 531 Prolog
% Assessed Exercise 3
% heap.pl


% Write your answers to the exercise here


% Task 1. is_heap(+H). Succeeds if H is a binary heap.
% Base Cases
is_heap(empty).  
              
is_heap(heap(_,_,empty,empty)). 

% Recursive cases
is_heap(heap(K,_,heap(KL,IL,LHL,RHL),heap(KR,IR,LHR,RHR))) :-  
	K >= KL,
	K >= KR,
	is_heap(heap(KL,IL,LHL,RHL)),
	is_heap(heap(KR,IR,LHR,RHR)).

is_heap(heap(K,_,empty,heap(KR,IR,LHR,RHR))) :- 
	K >= KR,
	is_heap(heap(KR,IR,LHR,RHR)).

is_heap(heap(K,_,heap(KL,IL,LHL,RHL),empty)) :- 
	K >= KL,
	is_heap(heap(KL,IL,LHL,RHL)).


  
% Task 2. add_to_heap(+K, +I, +H, -NewH). Add the node (K,I) with key K to max-heap H.
% Base cases 
add_to_heap(K, I, empty, heap(K,I,empty,empty)).

add_to_heap(K, I, heap(Kh, Ih, LH, empty), heap(K, I, heap(Kh,Ih,empty,empty), LH)) :-
	K >= Kh.

add_to_heap(K, I, heap(Kh, Ih, LH, empty), heap(Kh, Ih, heap(K,I,empty,empty), LH))  :-
	K < Kh.

% Recursive cases
add_to_heap(K, I, heap(Kh, Ih, LH, RH), heap(K,I,NewLH,LH)) :-
	K >= Kh,
	add_to_heap(Kh,Ih,RH,NewLH).

add_to_heap(K, I, heap(Kh, Ih, LH, RH), heap(Kh,Ih,NewLH,LH)) :-
	K < Kh,
	add_to_heap(K,I,RH,NewLH).


% Task 3. remove_max(+H, -K, -I, -NewH). Remove the node (K,I) with the highest valued key K from max-heap H.
% Trivial case
remove_max(heap(K,I,empty,empty),K,I,empty).

% Non trivial case
remove_max(H, K, I, NewH) :-
	remove_left(H,KL,IL,heap(K,I,LH,RH)),
	push_down(heap(KL,IL,LH,RH),NewH).


% remove_left(+H,-K,-I,-NewH). Remove a node from the left sub-heap.
remove_left(empty,_,_,_) :- fail.

% Base case
remove_left(heap(K,I,empty,_),K,I,empty).

% Recursive case
remove_left(heap(K,I,LH,RH),KR,IR,heap(K,I,RH,NewL)) :-
	remove_left(LH,KR,IR,NewL).

% push_down(+H, -NewH). Push the top node down the heap until the proper heap-ordering is restored.
% Base cases
push_down(heap(K,I,empty,empty),heap(K,I,empty,empty)).

push_down(heap(K,I,heap(KL,IL,LHL,RHL),heap(KR,IR,LHR,RHR)),heap(K,I,heap(KL,IL,LHL,RHL),heap(KR,IR,LHR,RHR))) :-
	K >= KR,
	K >= KL.

push_down(heap(K,I,heap(KL,IL,empty,empty),empty),heap(K,I,heap(KL,IL,empty,empty),empty)) :-
	K >= KL.

push_down(heap(K,I,heap(KL,IL,empty,empty),empty),heap(KL,IL,heap(K,I,empty,empty),empty)) :-
	K < KL.

% Recursive cases
push_down(heap(K,I,heap(KL,IL,LHL,RHL),heap(KR,IR,LHR,RHR)),heap(KR,IR,heap(KL,IL,LHL,RHL),NewH)) :-
	K < KR,
	push_down(heap(K,I,LHR,RHR),NewH).

push_down(heap(K,I,heap(KL,IL,LHL,RHL),heap(KR,IR,LHR,RHR)),heap(KL,IL,NewH,heap(KR,IR,LHR,RHR))) :-
	K < KL,
	push_down(heap(K,I,LHL,RHL),NewH).

% Task 4. heap_sort_asc(+L, -S). Sort the list L of (Key,Item) pairs into ascending order by key, returning the sorted list S.
% Trivial case
heap_sort_asc([], []).

% Non trivial case
heap_sort_asc(L,S) :-
	create_heap(L,empty,H),
	create_list(H,[],S).

% create_heap(+L, +Acc, -H). Creates a heap H with the elements of list L.
% Base case
create_heap([],H,H).

% Recursive case
create_heap([(K,I)|T],H,FinalH) :-
	add_to_heap(K,I,H,NewH),	
	create_heap(T,NewH,FinalH).

% create_list(+H, +Acc, -S). Creates a sorted list S with elements from heap H.
% Base case 
create_list(empty,S,S).

% Recursive case
create_list(H,S,FinalS) :-
	remove_max(H,K,I,NewH),
	create_list(NewH,[(K,I)|S],FinalS).

% Task 5. delete_from_heap(+I, +H, -NewH)
% Base case
delete_from_heap(I, heap(K,I,LH,RH), NewH) :-   
 	remove_max(heap(K,I,LH,RH),_,_,NewH).

% Recursive cases
delete_from_heap(I,heap(K,J,LH,RH), heap(K,J,RH,NewRH)) :-
	I \= J,
	delete_from_heap(I,LH,NewRH).

delete_from_heap(I,heap(K,J,LH,RH), heap(K,J,NewLH,NewRH)) :-
	I \= J,
	delete_from_heap(I,RH,TempLH),
	remove_left(LH,KL,IL,NewRH),
	add_to_heap(KL,IL,TempLH,NewLH).
