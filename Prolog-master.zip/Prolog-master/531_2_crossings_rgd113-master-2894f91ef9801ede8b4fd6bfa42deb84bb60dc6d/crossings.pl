%% File: crossings.pl
%% Name:
%% Date:
%%
%% This program is a solution to Prolog 531 Assessed Exercise 2 'Crossings'
%% The exercise is a version of the classic Farmer-Wolf-Goat-Cabbage Puzzle

%% Step 1 safe(+Bank)
safe(Bank):- member(f,Bank),!.
safe(Bank):- nonmember(g,Bank),!.
safe(Bank):- nonmember(w,Bank), nonmember(c,Bank),!.



%% Step 2 goal(+State)
goal([]-South):- 
	length(South,Length),
	Length == 5,
	member(f,South),
	member(w,South),
	member(g,South),
	member(c,South),
	member(b,South).        




%% Step 3 equiv(+State1, +State2)

equiv(N1-S1, N2-S2):- 
	equivv(N1,N2),
	equivv(S1,S2), !.

% equivv(+List1,+List2)
% succeeds if the lists are equivalent

% remove (Element+, List+, List-)
remove(H, [H|T], T).
remove(Element, [B, H|T], [B|C]) :-
	remove(Element, [H|T], C).


equivv([],[]).

equivv([H|T1],[H|T2]):-
	equivv(T1,T2).

equivv([H1|T1],[H2|T2]):-
	remove(H2,T1,A),
	remove(H1,T2,B),
	equivv(A,B).	

%% Step 4 visited(+State, +Sequence)
visited(State, [H|_]) :- 
	equiv(State,H),!.             % TODO replace this clause

visited(State, [_|T]) :- 
	visited(State,T).


%% Step 5 choose(-Items, +Bank)
choose([f,Item], Bank):- 
	remove(f,Bank,Nof),
	remove(Item,Nof,Safe),
	safe(Safe).             % TODO replace this clause

choose([f],Bank):-
	remove(f,Bank,Safe),
	safe(Safe).   

%% Step 6 journey(+State1, -State2)
journey(North1-South1, North2-South2):- 
	choose([H,T],North1),
	remove(H,North1,Int),
	remove(T,Int,North2),
	append(South1,[H,T],South2).
journey(North1-South1, North2-South2):- 
	choose([H],North1),
	remove(H,North1,North2),
	append(South1,[H],South2).
journey(North1-South1, North2-South2):- 
	choose([H,T],South1),
	remove(H,South1,Int),
	remove(T,Int,South2),
	append(North1,[H,T],North2).
journey(North1-South1, North2-South2):- 
	choose([H],South1),
	remove(H,South1,South2),
	append(North1,[H],North2).


%% Step 7 succeeds(-Sequence)
succeeds(Sequence) :-
	extend([ [f,w,g,c,b]-[] ], Sequence, [[f,w,g,c,b]-[]]).

extend([ State ], L, L):-
	equiv(State,[]-[f,w,g,c,b]).
extend([State1], Sequence, Visited) :-
	journey(State1,State2),
	\+visited(State2,Visited),
	append(Visited,[State2],Visited2),
	extend([State2],Sequence,Visited2).



%% Step 8 fee(+State1, +State2, -Fee)
fee(N1-_, N2-_, Fee):-	
	length(N2,L2),
	length(N1,L1),
	X is abs(L2-L1),
	X == 1,
	fees(Fee,_).             % TODO replace this clause
fee(N1-_, N2-_, Fee):- 
	length(N2,L2),
	length(N1,L1),
	X is abs(L2-L1),
	X == 2,
	fees(_,Fee). 

fees(F1,F2):-
	F1=1,
	F2=2.

%% Step 9 cost(-Sequence, -Cost)
cost(Sequence, Cost):-
	succeeds(Sequence),
	costt(Sequence,Cost).

costt([],0).
costt([_],0).
costt([S1,S2|T],Cost) :-
	fee(S1,S2,Fee),
	costt([S2|T],Cost2),
	Cost is Cost2+Fee.



