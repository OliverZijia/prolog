%% File: syllogisms.pl
%% Name:
%% Date:
%%
%% This program is a solution to Prolog 531 Assessed Exercise 5 'Syllogisms'
%% The exercise is to develop a parser and meta-interpreter for syllogistic
%% sentences, and use these to build a tool to determine the validity of a
%% syllogistic argument.

%% ---------------------------- Step 1 ---------------------------------------%%

%% opposite(+L, -Opp)

% Case 1
opposite([Article,B,'is'|[HT|TT]], Result) :- 
	Article \= 'no',
	Article \= 'some',
	HT \= 'not',
	append(['some',B,'is','not'],[HT|TT],Result).

opposite([B,'is'|T], Result) :- 
	append(['some',B,'is','not'],T,Result).

% Case 2
opposite(['some',B,'is','not'|T],Result) :- 
	append(['a',B,'is'],T,Result).

% Case 3
opposite(['no'|T], Result) :- 
	append(['some'],T,Result).

% Case 4
opposite(['some',B,'is'|[HT|TT]],Result) :-
	HT \= 'not',
	append(['no',B,'is'],[HT|TT],Result).

%% ---------------------------- Step 2 ---------------------------------------%%

%% Stage 2.1 - This is the suggested way to develop the solution.
%% Once Stage 2.2 is complete you can delete or comment out this code.
%% syllogism/0

% Case 1
syllogism --> art, [_] , [is], opt, [_].

% Case 2
syllogism --> [some], [_], [is], [not],  opt, [_].

% Case 3
syllogism --> [no], [_], [is], opt, [_].

% Case4
syllogism --> [some], [_], [is],  opt, [_].

% Define the possible articles
art --> [every]; [a].

% Define the possible optional articles
opt --> []; [a].

%% Stage 2.2 
%% syllogism(-Clauses)

% Case 1
syllogism([(Cclause :- Bclause)]) --> 
	art, 
	[B], 
	[is], 
	opt, 
	[C], 
	{Bclause =.. [B,X], 
	Cclause =.. [C,X]}.

% Case 2
syllogism([(Bclause:-true),(false:-Cclause)]) --> 
	[some], 
	[B], 
	[is], 
	[not],  
	opt, 
	[C],
	{Not =.. [not, C],
	Some =.. [some,B,Not],
	Bclause =.. [B,Some],
	Cclause =.. [C,Some]}.

% Case 3
syllogism([(false :- Bclause, Cclause)]) --> 
	[no], 
	[B], 
	[is], 
	opt, 
	[C],
	{Bclause =.. [B,X], 
	Cclause =.. [C,X]}.

% Case 4
syllogism([(Bclause :- true),(Cclause :- true)]) --> 
	[some], 
	[B], 
	[is],  
	opt, 
	[C],
	{Some =.. [some,B,C],
	Bclause =.. [B,Some],
	Cclause =.. [C,Some]}.


%% ---------------------------- Step 3 ---------------------------------------%%

%% translate(+N)

translate(N) :- 	
	forall((p(N,S),phrase(syllogism(Clause),S)),assertall(N,Clause)),
	c(N,Sc),
	opposite(Sc,O),
	phrase(syllogism(Clause1),O),
	assertall(N,Clause1).


%% ---------------------------- Step 4 ---------------------------------------%%

%% eval(+N, +Calls)

% Base case
eval(_,true).

% Recursive cases
eval(N,(H,T)) :-
	cl(N,H,B),
	eval(N,B),
	eval(N,T).

eval(N,H) :-
	cl(N,H,B),
	eval(N,B).

%% valid(?N)

valid(N) :- 
	eval(N,false).


%% invalid(?N)

invalid(N) :- 
	c(N,_),	
	\+eval(N,false).


%% ---------------------------- Step 5 ---------------------------------------%%

%% test(+N)

% Valid case
test(N) :- 
	valid(N),
	write('syllogism '),
	write(N),
	write(':\n'),
	forall(p(N,S),(write('   '),writeL(S),write('\n'))),
	write('=>\n'),
	c(N,Sc),
	write('   '),
	writeL(Sc),
	write('\n'),
	write('Premises and opposite conclusion converted to clauses:\n'),
	show_clauses(N),
	write('\n\nfalse can be derived, syllogism '),
	write(N),
	write(' is valid.').

% Invalid case
test(N) :- 
	invalid(N),
	write('syllogism '),
	write(N),
	write(':\n'),
	forall(p(N,S),(write('   '),writeL(S),write('\n'))),
	write('=>\n'),
	c(N,Sc),
	write('   '),
	writeL(Sc),
	write('\n'),
	write('Premises and opposite conclusion converted to clauses:\n'),
	show_clauses(N),
	write('\n\nfalse cannot be derived, syllogism '),
	write(N),
	write(' is invalid.').


