% 531 Prolog
% Assessed Exercise 1
% formulas.pl

:- consult(support).

% Write your answers to the exercise here

% Task 1: wff(+F)
% wff(F) holds when F is a (well-formed) formula.



wff(Atom) :-
	logical_atom(Atom).


wff(neg(Formula)) :-
	ground(Formula),	
	wff(Formula).

wff(and(X, Y)) :-
	ground(X),
	ground(Y),
	wff(X),
	wff(Y).

wff(or(X, Y)) :-
	ground(X),
	ground(Y),
	wff(X),
	wff(Y).

wff(imp(X, Y)) :-
	ground(X),
	ground(Y),	
	wff(X),
	wff(Y).


% Task 2: cls(+F)
% cls(F) holds when the formula F is a clause; a clause is either a literal or
% a disjunction of literals, and a literal is either an atom or a negated atom.

cls(Atom) :-
	ground(Atom),
	logical_atom(Atom).

cls(neg(Atom)) :-
	ground(Atom),
	logical_atom(Atom).

cls(or(X, Y)) :-
	ground(X),
	ground(Y),
	cls(X),
	cls(Y).
	

% Task 3: ats(+F, -As)
% given the formula F, returns As as a duplicate-free list (in any order) of 
% the atoms in F.

ats(F, Ats) :-
	wff(F),
	full_list(F, Allats),
	remove_duplicates(Allats, Ats).

full_list(neg(Formula), Allats) :-
	full_list(Formula, Allats).

full_list(and(X, Y), Allats) :-
	full_list(X, AllatsX),
	full_list(Y, AllatsY),
	append(AllatsX, AllatsY, Allats).

full_list(or(X, Y), Allats) :-
	full_list(X, AllatsX),
	full_list(Y, AllatsY),
	append(AllatsX, AllatsY, Allats).

full_list(imp(X, Y), Allats) :-
	full_list(X, AllatsX),
	full_list(Y, AllatsY),
	append(AllatsX, AllatsY, Allats).

full_list(Atom, [Atom]) :-
	logical_atom(Atom).

remove_duplicates([HeadAllats|TailAllats], Ats) :-
	member(HeadAllats, TailAllats),
	remove_duplicates(TailAllats, Ats).

remove_duplicates([HeadAllats|TailAllats], [HeadAllats|Ats]) :-
	\+ member(HeadAllats, TailAllats),
	remove_duplicates(TailAllats, Ats).

remove_duplicates([],[]).

% Task 4: t_value(+F, +Val, -V)
% Calculates the truth value V of the formula F, given the valuation Val.

%Truth Table 
and(t,t,t).
and(f,_,f).
and(_,f,f).
or(t,f,t).
or(f,t,t).
or(t,t,t).
or(f,f,f).
neg(f,t).
neg(t,f).
imp(X,Y) :-
	or(neg(X), Y).


t_value(Atom, Valuation, t) :-
	logical_atom(Atom),
	member(Atom, Valuation),
	!.

t_value(Atom, Valuation, f) :-
	logical_atom(Atom),
	\+ member(Atom, Valuation),
	!.

t_value(neg(Atom), Valuation, t) :-
	logical_atom(Atom),
	\+ member(Atom, Valuation),
	!.

t_value(neg(Atom), Valuation, f) :-
	logical_atom(Atom),
	member(Atom, Valuation),
	!.

t_value(or(X,Y), Valuation, Value) :-
	t_value(X, Valuation, Vx),
	t_value(Y, Valuation, Vy),
	or(Vx, Vy, Value).

t_value(and(X,Y), Valuation, Value) :-
	t_value(X, Valuation, Vx),
	t_value(Y, Valuation, Vy),
	and(Vx, Vy, Value).

t_value(imp(X,Y), Valuation, Value) :-
	t_value(X, Valuation, Vx),
	t_value(Y, Valuation, Vy),
	imp(Vx, Vy, Value).
